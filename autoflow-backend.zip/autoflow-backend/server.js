// ============================================================
// AutoFlow Backend — server.js
// ============================================================
const express = require('express');
const cors    = require('cors');
const dotenv  = require('dotenv');
const path    = require('path');
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname,'public')));

app.use('/api/automations', require('./routes/automations'));
app.use('/api/ai',          require('./routes/ai'));
app.use('/api/email',       require('./routes/email'));
app.use('/api/sheets',      require('./routes/sheets'));
app.use('/api/webhooks',    require('./routes/webhooks'));
app.use('/api/runs',        require('./routes/runs'));

app.get('/api/health', (_,res) => res.json({status:'ok',ts:new Date()}));
app.get('*', (_,res) => res.sendFile(path.join(__dirname,'public','index.html')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 AutoFlow on http://localhost:${PORT}`));
