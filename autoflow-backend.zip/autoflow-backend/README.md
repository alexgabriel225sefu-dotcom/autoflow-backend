# ⚡ AutoFlow — AI Automation Platform Backend

## Ce face acest backend

Acesta este serverul Node.js care face aplicația AutoFlow 100% funcțională:

| Endpoint | Ce face |
|---|---|
| `POST /api/automations/run/lead-followup` | Primește un lead → GPT scrie email → Gmail trimite → Sheets logghează |
| `POST /api/automations/run/whatsapp-bot` | Primește mesaj WhatsApp → GPT răspunde → trimite înapoi |
| `POST /api/automations/run/qualify-lead` | Clasifică lead HOT/WARM/COLD cu GPT |
| `POST /api/ai/generate` | Generează orice text cu GPT-4o |
| `POST /api/email/send` | Trimite email simplu via Gmail |
| `POST /api/sheets/append` | Adaugă rând în Google Sheets |
| `POST /api/webhooks/lead` | Webhook pentru Google Forms/Typeform |
| `POST /api/webhooks/whatsapp` | Webhook pentru 360dialog WhatsApp |
| `POST /api/webhooks/stripe` | Webhook pentru plăți Stripe |

---

## 🚀 Deploy în 15 minute pe Render.com (GRATUIT)

### Pasul 1 — Pregătire

```bash
# Clonează sau uploadează fișierele pe GitHub
git init
git add .
git commit -m "AutoFlow backend"
git remote add origin https://github.com/YOUR_USER/autoflow-backend.git
git push -u origin main
```

### Pasul 2 — Deploy pe Render

1. Mergi pe **render.com** → Sign up gratuit cu GitHub
2. **New → Web Service**
3. Conectează repo-ul tău
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Plan:** Free

### Pasul 3 — Environment Variables

În Render dashboard → Environment → Add:

```
OPENAI_API_KEY=sk-your-key
GMAIL_USER=your@gmail.com
GMAIL_APP_PASSWORD=your-app-password
GOOGLE_SERVICE_ACCOUNT_EMAIL=...
GOOGLE_PRIVATE_KEY=...
WHATSAPP_API_KEY=...
HUBSPOT_API_KEY=...
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

### Pasul 4 — Copiază UI-ul

Pune fișierul `autoflow-platform.html` în folderul `/public/index.html`

**Gata!** Aplicația rulează live la `https://autoflow-YOUR-NAME.onrender.com`

---

## 🔑 Cum obții fiecare API Key

### OpenAI
1. platform.openai.com → API Keys → Create key
2. Adaugă $5-10 credit în Billing

### Gmail App Password
1. myaccount.google.com → Security
2. Activează 2-Step Verification
3. App Passwords → Selectează "Mail" → Generate
4. Copiază parola de 16 caractere

### Google Sheets (Service Account)
1. console.cloud.google.com → New Project
2. Enable Google Sheets API
3. IAM & Admin → Service Accounts → Create
4. Keys → Add Key → JSON → Download
5. Copiază `client_email` și `private_key` din JSON
6. În Google Sheet → Share cu `client_email`

### 360dialog WhatsApp
1. 360dialog.com → Create account
2. Connect WhatsApp Business number
3. API Keys → Copy key
4. Set Webhook URL: `https://your-domain.com/api/webhooks/whatsapp`

### HubSpot
1. HubSpot → Settings → Integrations → Private Apps
2. Create app → All scopes → Generate token

---

## 📞 Test Rapid Local

```bash
# Instalează dependențele
npm install

# Pornește serverul
npm run dev

# Testează lead follow-up
curl -X POST http://localhost:3000/api/automations/run/lead-followup \
  -H "Content-Type: application/json" \
  -d '{"name":"Ion Pop","email":"ion@example.com","problem":"Vreau sa automatizez follow-up-ul la leaduri"}'

# Testează AI generation
curl -X POST http://localhost:3000/api/ai/generate \
  -H "Content-Type: application/json" \
  -d '{"prompt":"Scrie un email de follow-up pentru {{name}}","variables":{"name":"Maria"}}'
```

---

## 💰 Vinde-l ca SaaS

Cu acest backend poți construi un SaaS la care clienții plătesc lunar:

| Plan | Preț | Automatizări | Runs/lună |
|---|---|---|---|
| Starter | $49/lună | 3 | 5,000 |
| Pro | $97/lună | 10 | 25,000 |
| Agency | $197/lună | Nelimitat | 100,000 |

Adaugă autentificare cu **Supabase Auth** (gratuit) și billing cu **Stripe**.

---

## 📁 Structura Proiectului

```
autoflow-backend/
├── server.js              # Entry point
├── package.json           # Dependencies
├── .env.example           # Environment variables template
├── .env                   # Your real keys (NOT on GitHub!)
├── routes/
│   ├── automations.js     # Main automation engine
│   ├── ai.js              # GPT-4o integration
│   ├── email.js           # Gmail SMTP
│   ├── sheets.js          # Google Sheets
│   ├── webhooks.js        # External triggers
│   └── runs.js            # Execution logs
└── public/
    └── index.html         # Frontend UI (autoflow-platform.html)
```
