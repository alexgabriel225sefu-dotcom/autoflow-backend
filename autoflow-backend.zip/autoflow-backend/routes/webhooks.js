// routes/webhooks.js — Receive External Webhook Triggers
const express = require('express');
const router  = express.Router();
const axios   = require('axios');

// POST /api/webhooks/lead
// Called when a Google Form or Typeform is submitted
// This is the TRIGGER for the Lead Follow-Up automation
router.post('/lead', async (req, res) => {
  try {
    const body = req.body;

    // Extract data (handles Google Forms and Typeform formats)
    const name    = body.name || body.Name || body['Full Name'] || 'Unknown';
    const email   = body.email || body.Email || body['Email Address'] || '';
    const problem = body.problem || body.Problem || body.message || body.Message || '';

    if(!email) return res.status(400).json({ error: 'No email found in webhook data' });

    // Trigger the lead follow-up automation internally
    const response = await axios.post(
      `http://localhost:${process.env.PORT||3000}/api/automations/run/lead-followup`,
      { name, email, problem, spreadsheetId: process.env.DEFAULT_SHEET_ID }
    );

    console.log(`[Webhook] Lead processed: ${name} <${email}>`);
    res.json({ received: true, processed: true, result: response.data });

  } catch(err) {
    console.error('[Webhook:lead]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/webhooks/whatsapp
// Called by 360dialog when a WhatsApp message arrives
router.post('/whatsapp', async (req, res) => {
  try {
    const body = req.body;

    // 360dialog message format
    const messages = body?.messages || [];
    for(const msg of messages) {
      if(msg.type !== 'text') continue;
      const from    = msg.from;
      const text    = msg.text?.body || '';
      const profile = body?.contacts?.[0]?.profile?.name || 'Customer';

      await axios.post(
        `http://localhost:${process.env.PORT||3000}/api/automations/run/whatsapp-bot`,
        { from, message: text, businessName: process.env.BUSINESS_NAME }
      );

      console.log(`[Webhook] WhatsApp from ${from}: ${text.slice(0,50)}`);
    }

    res.json({ status: 'received' }); // 360dialog expects a fast 200 response
  } catch(err) {
    console.error('[Webhook:whatsapp]', err.message);
    res.json({ status: 'received' }); // still return 200 to prevent retries
  }
});

// POST /api/webhooks/stripe
// Called by Stripe when a payment succeeds
// Automatically sends course access email to buyer
router.post('/stripe', express.raw({type:'application/json'}), async (req, res) => {
  try {
    const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
    const sig    = req.headers['stripe-signature'];
    let event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    } catch(err) {
      return res.status(400).json({ error: 'Webhook signature invalid' });
    }

    if(event.type === 'payment_intent.succeeded') {
      const pi    = event.data.object;
      const email = pi.receipt_email || pi.metadata?.email;
      const name  = pi.metadata?.name || 'Student';
      const plan  = pi.metadata?.plan || 'starter';

      if(email) {
        const nodemailer = require('nodemailer');
        const transporter = nodemailer.createTransport({
          service: 'gmail',
          auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD }
        });

        await transporter.sendMail({
          from: `"AI Cash Systems" <${process.env.GMAIL_USER}>`,
          to: email,
          subject: `🎉 Welcome to AI Cash Systems ${plan === 'pro' ? 'PRO' : 'Starter'}!`,
          html: `
            <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto">
              <h1 style="color:#C8A96E">Welcome, ${name}! 🚀</h1>
              <p>Your payment was successful. Here's your course access:</p>
              <a href="${process.env.COURSE_URL || 'https://aicashsystems.com/members'}"
                style="display:inline-block;padding:14px 28px;background:#C8A96E;color:#000;border-radius:8px;text-decoration:none;font-weight:700;margin:20px 0">
                Access Your Course →
              </a>
              <p style="color:#666">Questions? Reply to this email anytime.</p>
            </div>
          `
        });
        console.log(`[Stripe] Course access sent to ${email}`);
      }
    }

    res.json({ received: true });
  } catch(err) {
    console.error('[Webhook:stripe]', err.message);
    res.status(500).json({ error: err.message });
  }
});

// GET /api/webhooks/test/:type — test your webhooks locally
router.get('/test/:type', async (req, res) => {
  const testData = {
    lead: { name: 'Test User', email: 'test@example.com', problem: 'I need help automating my lead follow-up' },
    whatsapp: { messages: [{ type: 'text', from: '40712345678', text: { body: 'Hi, I want to know more about your services' } }] }
  };
  res.json({ type: req.params.type, samplePayload: testData[req.params.type] || testData.lead });
});

module.exports = router;
