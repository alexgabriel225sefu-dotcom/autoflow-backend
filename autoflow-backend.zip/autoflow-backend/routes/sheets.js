// routes/sheets.js — Google Sheets Read/Write
const express    = require('express');
const router     = express.Router();
const { google } = require('googleapis');

// Google Auth via Service Account
function getAuth() {
  return new google.auth.GoogleAuth({
    credentials: {
      client_email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
      private_key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n')
    },
    scopes: ['https://www.googleapis.com/auth/spreadsheets']
  });
}

// POST /api/sheets/append
// Adds a row to a Google Sheet — used to log leads
router.post('/append', async (req, res) => {
  try {
    const { spreadsheetId, sheetName = 'Sheet1', values } = req.body;
    if(!spreadsheetId || !values) return res.status(400).json({ error: 'spreadsheetId and values required' });

    const auth   = getAuth();
    const sheets = google.sheets({ version: 'v4', auth });

    // values should be array like: [name, email, problem, timestamp]
    const rowValues = Array.isArray(values) ? values : Object.values(values);
    if(!rowValues.includes(new Date().toISOString().slice(0,19))) {
      rowValues.push(new Date().toISOString().slice(0,19)); // auto timestamp
    }

    const response = await sheets.spreadsheets.values.append({
      spreadsheetId,
      range: `${sheetName}!A:Z`,
      valueInputOption: 'USER_ENTERED',
      requestBody: { values: [rowValues] }
    });

    res.json({
      success: true,
      updatedRange: response.data.updates.updatedRange,
      rowsAdded: 1
    });
  } catch(err) {
    console.error('[Sheets] Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// GET /api/sheets/read
// Reads rows from a Google Sheet
router.get('/read', async (req, res) => {
  try {
    const { spreadsheetId, sheetName = 'Sheet1', limit = 100 } = req.query;
    if(!spreadsheetId) return res.status(400).json({ error: 'spreadsheetId required' });

    const auth   = getAuth();
    const sheets = google.sheets({ version: 'v4', auth });

    const response = await sheets.spreadsheets.values.get({
      spreadsheetId,
      range: `${sheetName}!A1:Z${limit}`
    });

    const rows = response.data.values || [];
    const headers = rows[0] || [];
    const data = rows.slice(1).map(row =>
      headers.reduce((obj, h, i) => ({ ...obj, [h]: row[i] || '' }), {})
    );

    res.json({ success: true, count: data.length, data });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
