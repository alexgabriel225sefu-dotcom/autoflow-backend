// routes/email.js — Gmail SMTP Email Sending
const express    = require('express');
const router     = express.Router();
const nodemailer = require('nodemailer');
const OpenAI     = require('openai');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Gmail transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_APP_PASSWORD  // Gmail App Password (not your login password)
  }
});

// POST /api/email/send
// Sends a plain email
router.post('/send', async (req, res) => {
  try {
    const { to, subject, body, html } = req.body;
    if(!to || !subject || (!body && !html)) {
      return res.status(400).json({ error: 'to, subject, and body/html are required' });
    }

    const info = await transporter.sendMail({
      from: `"AutoFlow" <${process.env.GMAIL_USER}>`,
      to, subject,
      text: body,
      html: html || `<p>${body.replace(/\n/g,'<br>')}</p>`
    });

    res.json({ success: true, messageId: info.messageId, to });
  } catch(err) {
    console.error('[Email] Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/email/ai-followup
// THE MAIN AUTOMATION: Generate AI email and send it
// This is the Lead Follow-Up automation from the course
router.post('/ai-followup', async (req, res) => {
  try {
    const { name, email, problem, companyName } = req.body;
    if(!name || !email) return res.status(400).json({ error: 'name and email required' });

    // Step 1: Generate personalized email with GPT-4o
    const prompt = `Write a friendly, professional follow-up email to ${name} who submitted this problem: "${problem || 'general inquiry'}".
Company reaching out: ${companyName || 'our team'}.
Keep it under 100 words. Be warm and helpful.
End with a clear CTA to book a free 15-minute call.
Do NOT include a subject line — just the email body.`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: 'You are a professional sales assistant who writes concise, warm follow-up emails.' },
        { role: 'user', content: prompt }
      ],
      max_tokens: 300
    });

    const aiBody = completion.choices[0].message.content;

    // Step 2: Send the AI-generated email via Gmail
    await transporter.sendMail({
      from: `"${companyName || 'AutoFlow'}" <${process.env.GMAIL_USER}>`,
      to: email,
      subject: `Hey ${name}, quick follow-up from us 👋`,
      text: aiBody,
      html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px">
        <p>${aiBody.replace(/\n\n/g,'</p><p>').replace(/\n/g,'<br>')}</p>
        <hr style="border:none;border-top:1px solid #eee;margin:24px 0"/>
        <p style="font-size:12px;color:#999">Sent via AutoFlow AI Automation</p>
      </div>`
    });

    res.json({
      success: true,
      to: email,
      name,
      aiGenerated: true,
      emailPreview: aiBody.slice(0, 150) + '...'
    });

  } catch(err) {
    console.error('[Email AI] Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/email/sequence
// Send a multi-step nurture sequence (Day 1, Day 3, Day 7)
router.post('/sequence', async (req, res) => {
  try {
    const { to, name, sequenceType } = req.body;
    // In production: schedule these with node-cron or a queue
    res.json({
      success: true,
      message: `Nurture sequence started for ${name} <${to}>`,
      scheduled: ['Day 1 - Welcome', 'Day 3 - Value email', 'Day 7 - Follow-up'],
      note: 'Emails will be sent via cron job scheduler'
    });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
