// routes/automations.js — Automation Flow Execution Engine
const express  = require('express');
const router   = express.Router();
const axios    = require('axios');
const OpenAI   = require('openai');
const nodemailer = require('nodemailer');
const { google } = require('googleapis');
const { v4: uuidv4 } = require('uuid');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// In-memory store for automations (use Supabase in production)
let automations = [
  {
    id: 'auto-001', name: 'Lead Follow-Up', status: 'active',
    trigger: 'webhook', runs: 2341,
    flow: ['google_form','gpt4o','gmail','google_sheets']
  },
  {
    id: 'auto-002', name: 'WhatsApp AI Bot', status: 'active',
    trigger: 'webhook', runs: 1892,
    flow: ['whatsapp_webhook','gpt4o','whatsapp_send']
  },
  {
    id: 'auto-003', name: 'Lead Qualification Agent', status: 'active',
    trigger: 'webhook', runs: 987,
    flow: ['typeform','gpt4o_classify','hubspot']
  }
];

let executionLogs = [];

// GET /api/automations — list all
router.get('/', (req, res) => {
  res.json({ success: true, automations });
});

// POST /api/automations — create new automation
router.post('/', (req, res) => {
  const { name, trigger, flow, config } = req.body;
  const automation = {
    id: 'auto-' + uuidv4().slice(0,8),
    name, trigger, flow, config,
    status: 'active', runs: 0,
    createdAt: new Date().toISOString()
  };
  automations.push(automation);
  res.json({ success: true, automation });
});

// PATCH /api/automations/:id/toggle — enable/disable
router.patch('/:id/toggle', (req, res) => {
  const auto = automations.find(a => a.id === req.params.id);
  if(!auto) return res.status(404).json({ error: 'Not found' });
  auto.status = auto.status === 'active' ? 'paused' : 'active';
  res.json({ success: true, id: auto.id, status: auto.status });
});

// DELETE /api/automations/:id
router.delete('/:id', (req, res) => {
  automations = automations.filter(a => a.id !== req.params.id);
  res.json({ success: true });
});

// ============================================================
// POST /api/automations/run/lead-followup
// THE MAIN AUTOMATION — runs the complete lead follow-up flow:
// 1. Receive lead data
// 2. Generate personalized email with GPT-4o
// 3. Send email via Gmail
// 4. Log lead to Google Sheets
// ============================================================
router.post('/run/lead-followup', async (req, res) => {
  const runId = uuidv4().slice(0,8);
  const startTime = Date.now();

  try {
    const { name, email, problem, spreadsheetId } = req.body;
    if(!name || !email) return res.status(400).json({ error: 'name and email required' });

    const log = { runId, automation: 'Lead Follow-Up', steps: [], success: false };

    // STEP 1: Generate AI email
    log.steps.push({ step: 1, name: 'GPT-4o Generate Email', status: 'running' });
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: 'You are a professional sales assistant. Write concise, warm follow-up emails.' },
        { role: 'user', content: `Write a follow-up email to ${name} who asked: "${problem || 'general inquiry'}". Max 80 words. End with CTA to book a free call. Email body only, no subject.` }
      ],
      max_tokens: 250
    });
    const aiEmail = completion.choices[0].message.content;
    log.steps[0].status = 'done';
    log.steps[0].output = aiEmail.slice(0,80) + '...';

    // STEP 2: Send email via Gmail
    log.steps.push({ step: 2, name: 'Gmail Send Email', status: 'running' });
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD }
    });
    await transporter.sendMail({
      from: `"AutoFlow" <${process.env.GMAIL_USER}>`,
      to: email,
      subject: `Hey ${name}, we got your message 👋`,
      text: aiEmail,
      html: `<p style="font-family:Arial;line-height:1.6">${aiEmail.replace(/\n/g,'<br>')}</p>`
    });
    log.steps[1].status = 'done';
    log.steps[1].output = `Email sent to ${email}`;

    // STEP 3: Log to Google Sheets (if spreadsheetId provided)
    if(spreadsheetId) {
      log.steps.push({ step: 3, name: 'Google Sheets Log', status: 'running' });
      try {
        const auth = new google.auth.GoogleAuth({
          credentials: {
            client_email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
            private_key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g,'\n')
          },
          scopes: ['https://www.googleapis.com/auth/spreadsheets']
        });
        const sheets = google.sheets({ version: 'v4', auth });
        await sheets.spreadsheets.values.append({
          spreadsheetId,
          range: 'Leads!A:E',
          valueInputOption: 'USER_ENTERED',
          requestBody: {
            values: [[
              new Date().toISOString().slice(0,19),
              name, email,
              problem || 'N/A',
              'Contacted'
            ]]
          }
        });
        log.steps[2].status = 'done';
        log.steps[2].output = 'Row added to Leads sheet';
      } catch(e) {
        log.steps[2].status = 'skipped';
        log.steps[2].output = 'Sheets skipped: ' + e.message;
      }
    }

    log.success = true;
    log.duration = Date.now() - startTime + 'ms';
    executionLogs.unshift(log);

    res.json({ success: true, runId, duration: log.duration, steps: log.steps, leadProcessed: { name, email } });

  } catch(err) {
    console.error('[Run:lead-followup]', err.message);
    executionLogs.unshift({ runId, automation: 'Lead Follow-Up', error: err.message, success: false });
    res.status(500).json({ error: err.message, runId });
  }
});

// ============================================================
// POST /api/automations/run/whatsapp-bot
// Receive WhatsApp message → GPT reply → Send back
// ============================================================
router.post('/run/whatsapp-bot', async (req, res) => {
  try {
    const { from, message, businessName } = req.body;
    if(!from || !message) return res.status(400).json({ error: 'from and message required' });

    // Generate reply with GPT-4o
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are a friendly assistant for ${businessName || 'our business'}. Reply to WhatsApp messages in max 2 sentences, casual but professional. If they seem interested in your services, suggest booking a call.`
        },
        { role: 'user', content: message }
      ],
      max_tokens: 150
    });
    const reply = completion.choices[0].message.content;

    // Send via 360dialog WhatsApp API
    if(process.env.WHATSAPP_API_KEY) {
      await axios.post(
        `https://waba.360dialog.io/v1/messages`,
        {
          to: from,
          type: 'text',
          text: { body: reply }
        },
        {
          headers: {
            'D360-API-KEY': process.env.WHATSAPP_API_KEY,
            'Content-Type': 'application/json'
          }
        }
      );
    }

    res.json({ success: true, from, reply, sent: !!process.env.WHATSAPP_API_KEY });

  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// POST /api/automations/run/qualify-lead
// Classify lead as HOT/WARM/COLD and route accordingly
// ============================================================
router.post('/run/qualify-lead', async (req, res) => {
  try {
    const { name, email, message, budget } = req.body;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: 'You are a lead qualification expert. Classify leads as HOT, WARM, or COLD based on buying intent, urgency and budget. Reply with ONLY the word: HOT, WARM, or COLD.'
        },
        {
          role: 'user',
          content: `Lead: ${name} | Email: ${email} | Message: ${message} | Budget: ${budget || 'not mentioned'}`
        }
      ],
      max_tokens: 5
    });

    const classification = completion.choices[0].message.content.trim().toUpperCase();
    const actions = {
      HOT:  { action: 'book_call',        message: 'Booking a discovery call automatically' },
      WARM: { action: 'send_email_sequence', message: 'Starting 3-email nurture sequence' },
      COLD: { action: 'tag_crm',          message: 'Tagged in CRM for future follow-up' }
    };

    res.json({
      success: true,
      classification,
      lead: { name, email },
      nextAction: actions[classification] || actions.COLD
    });

  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/automations/logs — execution history
router.get('/logs', (req, res) => {
  res.json({ success: true, logs: executionLogs.slice(0, 50) });
});

// GET /api/automations/stats
router.get('/stats', (req, res) => {
  res.json({
    success: true,
    totalAutomations: automations.length,
    activeAutomations: automations.filter(a => a.status === 'active').length,
    totalRuns: automations.reduce((s,a) => s + (a.runs||0), 0),
    successRate: '99.8%',
    hoursSaved: 142
  });
});

module.exports = router;
