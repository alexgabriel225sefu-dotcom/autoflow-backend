// routes/ai.js — OpenAI GPT-4o Integration
const express = require('express');
const router  = express.Router();
const OpenAI  = require('openai');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// POST /api/ai/generate
// Body: { prompt, systemPrompt, variables }
// Calls GPT-4o and returns the generated text
router.post('/generate', async (req, res) => {
  try {
    const { prompt, systemPrompt, variables = {} } = req.body;
    if(!prompt) return res.status(400).json({ error: 'prompt is required' });

    // Replace {{variable}} placeholders with actual values
    let finalPrompt = prompt;
    Object.entries(variables).forEach(([key, val]) => {
      finalPrompt = finalPrompt.replace(new RegExp(`{{${key}}}`, 'g'), val);
    });

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt || 'You are a helpful AI assistant.' },
        { role: 'user',   content: finalPrompt }
      ],
      max_tokens: 1000,
      temperature: 0.7
    });

    const output = completion.choices[0].message.content;
    res.json({ success: true, output, tokens: completion.usage });
  } catch(err) {
    console.error('[AI] Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/ai/classify
// Classifies a lead as HOT / WARM / COLD
router.post('/classify', async (req, res) => {
  try {
    const { name, email, message, budget } = req.body;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: 'You are a lead qualification expert. Classify leads as HOT, WARM, or COLD. Reply with ONLY the classification word.'
        },
        {
          role: 'user',
          content: `Classify this lead:\nName: ${name}\nEmail: ${email}\nMessage: ${message}\nBudget mentioned: ${budget || 'not specified'}`
        }
      ],
      max_tokens: 10
    });

    const classification = completion.choices[0].message.content.trim().toUpperCase();
    res.json({ success: true, classification, lead: { name, email } });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/ai/chat
// Full chat conversation for the AI Builder
router.post('/chat', async (req, res) => {
  try {
    const { messages } = req.body;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are AutoFlow AI, an expert in building AI automations for businesses. 
When a user describes what they want to automate, you:
1. Design the complete automation flow with specific steps
2. Specify which apps/tools connect (Make.com, Gmail, GPT, Sheets, WhatsApp, HubSpot etc.)
3. Write the exact AI prompts they should use
4. Give a recommended price to sell this to clients
Be specific, practical and actionable. Format responses clearly with steps.`
        },
        ...messages
      ],
      max_tokens: 800
    });

    res.json({ success: true, reply: completion.choices[0].message.content });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
